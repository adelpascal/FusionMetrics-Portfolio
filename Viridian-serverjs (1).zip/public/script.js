            document.addEventListener('DOMContentLoaded', function () {
              // Modal Elements
              const signInModal = document.getElementById('signInModal');
              const signInForm = document.getElementById('signInForm');
              const signUpModal = document.getElementById('signUpModal');
              const signUpForm = document.getElementById('signUpForm');
              const emailVerificationStep = document.getElementById('emailVerificationStep');
              const securitySetupStep = document.getElementById('securitySetupStep');
              const passwordSetupModal = document.getElementById('passwordSetupModal');

              // Buttons
              const verifyButton = document.getElementById('verifyButton');
              const cancelVerification = document.getElementById('cancelVerification');
              const continueButton = document.getElementById('continueButton');
              const cancelSecuritySetup = document.getElementById('cancelSecuritySetup');
              const setPasswordButton = document.getElementById('setPasswordButton');
              const saveSubscriptionsButton = document.getElementById('saveSubscriptionsButton');

              // User UI Elements
              const userAvatar = document.getElementById('userAvatar');
              const userDropdownContainer = document.getElementById('userDropdownContainer');
              const authButtons = document.querySelector('.auth-buttons');

              // "Select All" Checkboxes
              const selectAllNewsletters = document.getElementById('selectAllNewsletters');
              const selectAllIndustries = document.getElementById('selectAllIndustries');
              const selectAllBusinessTopics = document.getElementById('selectAllBusinessTopics');

              // Individual Checkboxes (using class selectors)
              const newsletterCheckboxes = document.querySelectorAll('.newsletter-checkbox');
              const industryCheckboxes = document.querySelectorAll('.industry-checkbox');
              const businessTopicCheckboxes = document.querySelectorAll('.business-topic-checkbox');

              // Save Changes Button Container
              const saveChangesContainer = document.getElementById('saveChangesContainer');

              // Sign-in Form Submission
              if (signInForm) {
                signInForm.addEventListener('submit', function (event) {
                  event.preventDefault();
                  const email = document.getElementById('signInEmail').value;
                  const password = document.getElementById('signInPassword').value;

                  console.log('Sign-In Data:', { email, password });

                  fetch('/signin', {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ email, password })
                  })
                    .then(response => {
                      if (!response.ok) {
                        throw new Error('Sign-in failed');
                      }
                      return response.json();
                    })
                    .then(data => {
                      console.log('Sign-in successful:', data);
                      updateUserUI(data);
                      bootstrap.Modal.getInstance(signInModal).hide();
                    })
                    .catch(error => {
                      console.error('Sign-in Error:', error);
                      // Handle the error
                    });
                });
              }

              // Sign-Up Form Submission
              if (signUpForm) {
                signUpForm.addEventListener('submit', async function(event) {
                  event.preventDefault();
                  const firstName = document.getElementById('signUpFirstName').value;
                  const lastName = document.getElementById('signUpLastName').value;
                  const email = document.getElementById('signUpEmail').value;
                  const password = document.getElementById('signUpPassword').value;
                  const verifyPassword = document.getElementById('verifyPassword').value; // Make sure this ID exists in your signup form
                  const termsCheck = document.getElementById('termsCheck').checked; // Make sure this ID exists in your signup form

                  if (password !== verifyPassword) {
                    alert('Passwords do not match!');
                    return;
                  }

                  if (!termsCheck) {
                    alert('You must agree to the terms and conditions!');
                    return;
                  }

                  try {
                    const response = await fetch('/signup', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        firstName,
                        lastName,
                        email,
                        password
                      })
                    });

                    if (!response.ok) {
                      const err = await response.json(); 
                      throw new Error(`Server Error: ${err.message || response.statusText}`);
                    }

                    const message = await response.text(); 
                    console.log('Server Response:', message);

                    // Instead of hiding the form, you might want to:
                    // 1. Display a success message to the user.
                    // 2. Clear the form fields.
                    // 3. Automatically move to the email verification step (if that's your intended flow).

                    // signUpForm.style.display = 'none'; 
                    // emailVerificationStep.style.display = 'block';
                    document.getElementById('verificationEmail').value = email; 
                  } catch (error) {
                    console.error('Error during sign-up:', error);
                    // Handle error appropriately, e.g., display an error message to the user
                  }
                });
              }

              // Email Verification
              if (verifyButton) {
                verifyButton.addEventListener('click', async function() {
                  const email = document.getElementById('verificationEmail').value; 
                  const code = document.getElementById('verificationCode').value;

                  console.log('Verification Code:', code);

                  try {
                    const response = await fetch('/verify', { 
                      method: 'POST',
                      headers: {
                        'Content-Type': 'application/json'
                      },
                      body: JSON.stringify({ email, code }) 
                    });

                    if (!response.ok) {
                      throw new Error('Verification failed'); 
                    }

                    const data = await response.json();
                    console.log('Verification successful:', data);

                    // You might want to:
                    // 1. Display a success message.
                    // 2. Redirect the user to the login page or another appropriate page.
                    // 3. Update the UI to show that the user is now verified.

                    window.location.reload();
                  } catch (error) {
                    console.error('Verification Error:', error);
                    // Handle the error (e.g., display an error message to the user)
                  }
                });
              }

              // Set Password
              if (setPasswordButton) {
                setPasswordButton.addEventListener('click', async function () {
                  const email = document.getElementById('verificationEmail').value; 
                  const newPassword = document.getElementById('newPassword').value;
                  const confirmPassword = document.getElementById('confirmPassword').value;

                  console.log('New Password:', newPassword);

                  if (newPassword === confirmPassword) {
                    try {
                      const response = await fetch('/setpassword', { 
                        method: 'POST',
                        headers: {
                          'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ email, newPassword })
                      });

                      if (!response.ok) {
                        throw new Error('Password update failed'); 
                      }

                      const data = await response.json(); 
                      console.log('Password updated successfully:', data);
                      bootstrap.Modal.getInstance(passwordSetupModal).hide();

                      // Proceed to the next step or redirect to login
                      switchModalStep(passwordSetupModal, securitySetupStep); // Adjust as needed
                    } catch (error) {
                      console.error('Password Update Error:', error);
                    }
                  } else {
                    alert('Passwords do not match!'); 
                  }
                });
              }

              // Other Button Actions
              if (cancelVerification) {
                cancelVerification.addEventListener('click', function () {
                  switchModalStep(emailVerificationStep, signUpForm);
                });
              }

              if (cancelSecuritySetup) {
                cancelSecuritySetup.addEventListener('click', function () {
                  switchModalStep(securitySetupStep, signUpForm);
                });
              }

              if (continueButton) {
                continueButton.addEventListener('click', function () {
                  console.log('Continuing after security setup...');
                  bootstrap.Modal.getInstance(signUpModal).hide();
                });
              }

              // Function to fetch and update user details
              function fetchUserDetails() {
                fetch('/user')
                  .then(response => {
                    if (!response.ok) {
                      throw new Error('User not logged in');
                    }
                    return response.json(); 
                  })
                  .then(data => {
                    console.log('User Details:', data);
                    updateUserUI(data); 
                    loadUserSubscriptions(data.email); 
                  })
                  .catch(error => {
                    console.error('Error fetching user details:', error);
                    // Handle the error 
                  });
              }

              // Function to update the UI based on user data
              function updateUserUI(user) {
                if (authButtons) {
                  authButtons.style.display = 'none'; 
                }

                if (userAvatar && userDropdownContainer) {
                  userAvatar.style.display = 'inline'; 

                  userDropdownContainer.innerHTML = `
                    <ul class="user-dropdown">
                      <li>
                        <a class="dropdown-option" href="#">
                          <span>Hi, ${user.firstName || ''} ${user.lastName || ''}</span>
                        </a>
                      </li>
                      <li><a class="dropdown-option" href="/userprofile">Edit Profile</a></li>
                      <li><a class="dropdown-option" href="/subscriptions">Manage Subscriptions</a></li>
                      <li><a class="dropdown-option" href="#">My Saved Content</a></li>
                      <li><hr class="dropdown-divider"></li>
                      <li>
                        <a class="dropdown-option" href="#" id="logoutButton">Log out</a>
                      </li>
                    </ul>
                  `;
                  userDropdownContainer.style.display = 'block';

                  // Add click listener to the avatar icon 
                  userAvatar.addEventListener('click', function() {
                    if (userDropdownContainer.style.display === 'none') {
                      userDropdownContainer.style.display = 'block';
                    } else {
                      userDropdownContainer.style.display = 'none'; 
                    }
                  });

                  // Logout button event listener
                  const logoutButton = document.getElementById('logoutButton');
                  if (logoutButton) {
                    logoutButton.addEventListener('click', function() {
                      fetch('/logout', {
                        method: 'POST',
                      })
                      .then(response => response.json()) 
                      .then(data => {
                        console.log('Logged out:', data);
                        authButtons.style.display = 'block'; 
                        userDropdownContainer.style.display = 'none';
                        userAvatar.style.display = 'none'; 
                        location.reload(); 
                      })
                      .catch(error => {
                        console.error('Error during logout:', error);
                        // Handle the error 
                      });
                    });
                  }

            // Handle Edit Profile form submission 
            if (editProfileForm) {
                editProfileForm.addEventListener('submit', async function (event) {
                    event.preventDefault();
                    const formData = new FormData(editProfileForm);
                    const email = document.querySelector('input[name="email"]').value;

                    try {
                        const response = await fetch('/editprofile', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({
                                email: email,
                                firstName: formData.get('firstName'),
                                lastName: formData.get('lastName'),
                            })
                        });

                        if (!response.ok) {
                            throw new Error('Profile update failed');
                        }

                        const message = await response.text();
                        console.log('Server response:', message);
                    } catch (error) {
                        console.error('Profile update error:', error); 
                    }
                });
            }
        }
    }

    // Close the submenu when clicking outside 
    document.body.addEventListener('click', (event) => {
        if (
            !event.target.closest('.offcanvas') &&
            !event.target.closest('.sub-menu-container') &&
            !event.target.closest('#userAvatar') && 
            !event.target.closest('.user-dropdown') 
        ) {
            const collapseElements = document.querySelectorAll('.collapse.show');
            collapseElements.forEach(element => {
                bootstrap.Collapse.getInstance(element).hide();
            });

            userDropdownContainer.style.display = 'none';
        }
    });

    // Function to switch between modal steps
    function switchModalStep(currentStep, nextStep) {
        currentStep.classList.remove('active');
        nextStep.classList.add('active');
    }

    // Function to generate a random verification code
    function generateVerificationCode(length) {
        let code = "";
        const characters = "0123456789"; 
        for (let i = 0; i < length; i++) {
            code += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        return code;
    }

    // Function to load and display user subscriptions
    async function loadUserSubscriptions(email) {
        try {
            const response = await fetch(`/getsubscriptions?email=${email}`);
            if (!response.ok) {
                throw new Error('Failed to fetch subscriptions');
            }

            const userSubscriptions = await response.json();
            console.log('User Subscriptions:', userSubscriptions);
            setCheckedStatus(newsletterCheckboxes, userSubscriptions.newsletters);
            setCheckedStatus(industryCheckboxes, userSubscriptions.industries);
            setCheckedStatus(businessTopicCheckboxes, userSubscriptions.businessTopics);
            updateSelectAllCheckboxes();
        } catch (error) {
            console.error('Error loading subscriptions:', error);
        }
    }

    // Helper function to set the 'checked' status of checkboxes
    function setCheckedStatus(checkboxes, selectedValues) {
        checkboxes.forEach(checkbox => {
            checkbox.checked = selectedValues.includes(checkbox.id);
        });
    }

    // Function to update the "Select All" checkboxes 
    function updateSelectAllCheckboxes() {
        selectAllNewsletters.checked = areAllCheckboxesChecked(newsletterCheckboxes);
        selectAllIndustries.checked = areAllCheckboxesChecked(industryCheckboxes);
        selectAllBusinessTopics.checked = areAllCheckboxesChecked(businessTopicCheckboxes);
    }

    // Helper function to check if all checkboxes in a group are checked
    function areAllCheckboxesChecked(checkboxes) {
        return Array.from(checkboxes).every(checkbox => checkbox.checked);
    }

    // Function to show the "Save Changes" button
    function showSaveChangesButton() {
        saveChangesContainer.style.display = 'block';
    }

    // "Select All" Checkbox Event Listeners
    selectAllNewsletters.addEventListener('change', function () {
        toggleAllCheckboxes(newsletterCheckboxes, this.checked);
        saveUserPreferences('newsletters');
        showSaveChangesButton(); 
    });

    selectAllIndustries.addEventListener('change', function () {
        toggleAllCheckboxes(industryCheckboxes, this.checked);
        saveUserPreferences('industries');
        showSaveChangesButton(); 
    });

    selectAllBusinessTopics.addEventListener('change', function () {
        toggleAllCheckboxes(businessTopicCheckboxes, this.checked);
        saveUserPreferences('businessTopics');
        showSaveChangesButton(); 
    });

    // Helper function to toggle all checkboxes in a group
    function toggleAllCheckboxes(checkboxes, isChecked) {
        checkboxes.forEach(checkbox => {
            checkbox.checked = isChecked;
        });
    }

    // Function to save user preferences to the server
    async function saveUserPreferences(preferenceType) {
        const selectedValues = getSelectedCheckboxValues(document.querySelectorAll(`.${preferenceType}-checkbox:checked`));
        const email = document.getElementById('userEmail').value; // Get logged-in user's email

        try {
            const response = await fetch('/savesubscriptions', { 
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    email: email,
                    [preferenceType]: selectedValues 
                })
            });

            if (!response.ok) {
                throw new Error(`Failed to save ${preferenceType} preferences`);
            }

            const message = await response.text();
            console.log(message); 
            alert('Your subscriptions have been updated.'); 
        } catch (error) {
            console.error(`Error saving ${preferenceType} preferences:`, error);
        }
    }

    // Helper function to get the values of checked checkboxes
    function getSelectedCheckboxValues(checkboxes) {
        return Array.from(checkboxes).map(checkbox => checkbox.id);
    }

    // Function to display a success message 
    function displaySuccessMessage() {
        alert('Saved Successfully!\nYour subscriptions have been updated.'); 
    }

    // Individual Checkbox Event Listeners 
    newsletterCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            updateSelectAllCheckboxes();
            showSaveChangesButton(); 
            saveUserPreferences('newsletters');
        });
    });

    industryCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            updateSelectAllCheckboxes();
            showSaveChangesButton(); 
            saveUserPreferences('industries');
        });
    });

    businessTopicCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', () => {
            updateSelectAllCheckboxes();
            showSaveChangesButton(); 
            saveUserPreferences('businessTopics');
        });
    });

    // Save Changes Button Event Listener
    saveSubscriptionsButton.addEventListener('click', async function () {
        try {
            // Save all types of preferences
            await Promise.all([
                saveUserPreferences('newsletters'),
                saveUserPreferences('industries'),
                saveUserPreferences('businessTopics')
            ]);

            displaySuccessMessage(); 
            saveChangesContainer.style.display = 'none';
        } catch (error) {
            console.error('Error saving subscriptions:', error);
        }
    });

    // ---------------------- Google Sign-In ----------------------

    // Send the ID token to your server
    function onSignIn(googleUser) {
        const profile = googleUser.getBasicProfile();
        console.log('ID: ' + profile.getId()); // Do not send to your backend! Use only for your reference.
        console.log('Name: ' + profile.getName());
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail());
        const id_token = googleUser.getAuthResponse().id_token;
        fetch('/auth/google/token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id_token: id_token
            })
        })
        .then(response => response.json())
        .then(data => {
            console.log('Server response:', data);
            window.location.href = '/';
        })
        .catch(error => {
            console.error('Error sending token to server:', error);
        });
    }
    // Render the "Sign In with Google" button
    function renderButton() {
        gapi.signin2.render('googleSignInButton', {
            'scope': 'profile email',
            'width': 240,
            'height': 50,
            'longtitle': true,
            'theme': 'dark',
            'onsuccess': onSignIn,
            'onfailure': function (error) {
                console.log('Google Sign-In Error:', error);
            }
        });
    }
    // Load the Google API Client library and initialize the button
    function startApp() {
        gapi.load('auth2', () => {
            gapi.auth2.init({
                client_id: '546701819172-8c5vmnr4e72dds7v1d8ractufhgpieha.apps.googleusercontent.com' // Replace with your actual Client ID
            }).then(() => {
                renderButton(); 
            });
        });
    }
    fetchUserDetails();
    startApp(); 
});