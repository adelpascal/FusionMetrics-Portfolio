const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const Mailjet = require('node-mailjet');
const session = require('express-session');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const { OAuth2Client } = require('google-auth-library');
const dotenv = require('dotenv');
dotenv.config();

// Import User model correctly
const User = require('./models/User');

const app = express();
const PORT = process.env.PORT || 3002; // Changed port number to 3002

// ---------------------- Database Setup ----------------------

const uri = "mongodb+srv://adelianurdamapa:hjLXuAbm1wXvY9Zm@viridian-cluster.kxudhff.mongodb.net/?retryWrites=true&w=majority&appName=Viridian-Cluster";

// MongoDB Atlas connection
(async () => {
  try {
    await mongoose.connect(uri);
    console.log('Connected to MongoDB!');
  } catch (err) {
    console.error('Could not connect to MongoDB...', err.message);
  }
})();

// ---------------------- Middleware ----------------------

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.JWT_SECRET || 'default-secret', // Provide a default secret in case the environment variable is missing
  resave: false,
  saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());
app.use(express.static(path.join(__dirname, 'public')));

// ---------------------- Mailjet Setup ----------------------

const mailjet = Mailjet.apiConnect(
  process.env.MJ_APIKEY_PUBLIC,
  process.env.MJ_APIKEY_PRIVATE
);

// Generating a random verification code
const generateVerificationCode = (length) => {
  let result = '';
  const characters = '0123456789'; // Using numbers only
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
};

// Sending verification email with Mailjet
function sendEmailWithMailjet(recipientEmail, code) {
  return mailjet.post("send", { 'version': 'v3.1' }).request({
    "Messages": [
      {
        "From": {
          "Email": "adelianurdamapa@gmail.com",
          "Name": "Viridian Consulting"
        },
        "To": [
          {
            "Email": recipientEmail,
            "Name": "Recipient Name"
          }
        ],
        "Subject": "Verify Your Email Address",
        "TextPart": `Welcome to Viridian! Please verify your email by entering this code: ${code}`,
        "HTMLPart": `<h1>Welcome to Viridian!</h1><p>Please verify your email by entering this code: <b>${code}</b></p>`
      }
    ]
  });
}

// ---------------------- Passport.js Google Strategy ----------------------

passport.use(
  new GoogleStrategy(
    {
      clientID: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackURL: "https://79c87270-126c-4d50-a6ff-e481030b6c76-00-12cw2i8qt9459.sisko.replit.dev:3002/auth/google/callback" // Sesuaikan dengan asal JavaScript yang Anda daftarkan
    },
    async (accessToken, refreshToken, profile, done) => {
      try {
        let user = await User.findOne({ email: profile.emails[0].value });
        if (user) {
          if (!user.googleId) {
            user.googleId = profile.id;
            user.accessToken = accessToken; // Simpan accessToken
            user.refreshToken = refreshToken; // Simpan refreshToken
            user = await user.save();
          }
        } else {
          user = new User({
            googleId: profile.id,
            firstName: profile.name.givenName,
            lastName: profile.name.familyName,
            email: profile.emails[0].value,
            accessToken: accessToken, // Simpan accessToken
            refreshToken: refreshToken, // Simpan refreshToken,
            isVerified: true
          });
          user = await user.save();
        }
        return done(null, user);
      } catch (err) {
        return done(err, null);
      }
    }
  )
);

passport.serializeUser((user, done) => {
  done(null, user.id);
});

passport.deserializeUser((id, done) => {
  User.findById(id, (err, user) => {
    done(err, user);
  });
});

// ---------------------- Routes ----------------------

// Google Authentication Routes
app.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

app.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/' }), 
  (req, res) => {
    res.redirect('/');
  }
);


// Route for handling sign-up form data
app.post('/signup', async (req, res) => {
    const { firstName, lastName, email, password } = req.body;
    const verificationCode = generateVerificationCode(6);
    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).send({ error: 'User already exists.' });
        }
        const hash = await bcrypt.hash(password, 10);
        const newUser = new User({
            firstName,
            lastName,
            email,
            password: hash,
            verificationCode,
            isVerified: false,
            newsletters: [],
            industries: [],
            businessTopics: []
        });
        await newUser.save();
        // Send verification email
        await sendEmailWithMailjet(email, verificationCode);
        res.send('Verification email sent!');
    } catch (err) {
        console.error('Error during sign-up:', err);
        res.status(500).send({ error: 'Internal server error.' });
    }
});

// Route for verifying the code
app.post('/verify', async (req, res) => {
  const { email, code } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).send({ message: 'User not found.' });
    }

    if (user.verificationCode === code) {
      user.isVerified = true;
      user.verificationCode = undefined;
      await user.save();
      req.session.user = user;
      res.send({ message: 'Verification successful!' });
    } else {
      res.status(400).send({ message: 'Invalid verification code.' });
    }
  } catch (error) {
    console.error('Error during verification:', error);
    res.status(500).send('Server error during verification.');
  }
});

// Route for requesting a password reset
app.post('/forgotpassword', async (req, res) => {
  const { email } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).send({ message: 'User not found.' });
    }

    const resetToken = generateVerificationCode(6);
    user.verificationCode = resetToken;
    await user.save();

    await sendEmailWithMailjet(user.email, user.verificationCode);

    res.send({ message: 'If a user with that email exists, a password reset email has been sent.' });

  } catch (error) {
    console.error('Error during password reset:', error);
    res.status(500).send('Error during password reset.');
  }
});

// Route for handling the password reset link
app.get('/resetpassword/:token', async (req, res) => {
  const token = req.params.token;

  try {
    const user = await User.findOne({ verificationCode: token });
    if (!user) {
      return res.status(400).send('Invalid or expired token.');
    }
    res.sendFile(path.join(__dirname, 'public', 'resetpassword.html'));
  } catch (error) {
    console.error('Error finding user with token:', error);
    res.status(500).send('Server error.');
  }
});

// Route for setting the new password
app.post('/resetpassword/:token', async (req, res) => {
  const token = req.params.token;
  const { newPassword } = req.body;

  try {
    const user = await User.findOne({ verificationCode: token });
    if (!user) {
      return res.status(400).send('Invalid or expired token.');
    }

    const hash = await bcrypt.hash(newPassword, 10);
    user.password = hash;
    user.verificationCode = undefined;
    await user.save();

    res.send('Password reset successful! You can now log in with your new password.');
  } catch (error) {
    console.error('Error during password reset:', error);
    res.status(500).send('Error resetting password.');
  }
});

// Route to handle user logout
app.post('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error('Error destroying session:', err);
      res.status(500).send({ message: 'Logout failed' });
    } else {
      res.send({ message: 'Logged out successfully' });
    }
  });
});

// Route for sign-in
app.post('/signin', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).send({ message: 'Invalid credentials.' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).send({ message: 'Invalid credentials.' });
    }

    if (!user.isVerified) {
      return res.status(401).send({ message: 'Account not verified.' });
    }

    req.session.user = user;
    res.send({ message: 'Sign-in successful!', user });

  } catch (error) {
    console.error('Error during sign-in:', error);
    res.status(500).send('Server error during sign-in.');
  }
});

// Route for the homepage (serving index.html)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Route for user profile editing
app.get('/userprofile', (req, res) => {
  if (req.session.user) {
    res.sendFile(path.join(__dirname, 'public', 'userprofile.html'));
  } else {
    res.redirect('/');
  }
});

// Route to handle profile update
app.post('/editprofile', async (req, res) => {
  if (req.session.user) {
    const { firstName, lastName } = req.body;
    const email = req.session.user.email;

    try {
      const updatedUser = await User.findOneAndUpdate(
        { email },
        { firstName, lastName },
        { new: true }
      );
      if (!updatedUser) {
        return res.status(404).send({ message: 'User not found.' });
      }

      req.session.user.firstName = firstName;
      req.session.user.lastName = lastName;

      res.send('Profile updated successfully!');
    } catch (error) {
      console.error('Error updating profile:', error);
      res.status(500).send('Error updating profile.');
    }
  } else {
    res.status(401).send({ message: 'User not logged in' });
  }
});

// Route to get user subscriptions
app.get('/getsubscriptions', async (req, res) => {
  try {
    const user = await User.findOne({ email: req.query.email });
    if (!user) {
      return res.status(404).send({ message: 'User not found.' });
    }
    res.send({
      newsletters: user.newsletters,
      industries: user.industries,
      businessTopics: user.businessTopics
    });
  } catch (error) {
    console.error('Error fetching subscriptions:', error);
    res.status(500).send('Error fetching subscriptions.');
  }
});

// Route to save user subscriptions
app.post('/savesubscriptions', async (req, res) => {
  try {
    const updatedUser = await User.findOneAndUpdate(
      { email: req.body.email },
      {
        newsletters: req.body.newsletters,
        industries: req.body.industries,
        businessTopics: req.body.businessTopics
      },
      { new: true }
    );
    if (!updatedUser) {
      return res.status(404).send({ message: 'User not found.' });
    }
    res.send('Subscriptions saved successfully!');
  } catch (error) {
    console.error('Error saving subscriptions:', error);
    res.status(500).send('Error saving subscriptions.');
  }
});

// Route for the subscriptions page (serving subscriptions.html)
app.get('/subscriptions', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'subscriptions.html'));
});

app.post('/auth/google/token', (req, res) => {
  const idToken = req.body.id_token;
  const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

  async function verify() {
    try {
      const ticket = await client.verifyIdToken({
        idToken,
        audience: process.env.GOOGLE_CLIENT_ID
      });
      const payload = ticket.getPayload();

      let user = await User.findOne({ email: payload.email });

      if (user) {
        if (!user.googleId) {
          user.googleId = payload['sub'];
          user = await user.save();
        }
      } else {
        user = new User({
          googleId: payload['sub'],
          firstName: payload.given_name,
          lastName: payload.family_name,
          email: payload.email,
          isVerified: true,
          newsletters: [],
          industries: [],
          businessTopics: []
        });
        user = await user.save();
      }

      req.session.user = user;
      res.send({ message: 'Token verified successfully!', user });
    } catch (err) {
      console.error('Error during Google authentication:', err);
      res.status(500).send('Error during Google authentication.');
    }
  }

  verify().catch(console.error);
});

// Start the server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server listening on port ${PORT}`);
});