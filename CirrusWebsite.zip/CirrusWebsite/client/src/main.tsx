import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { useEffect } from "react";

// Function to handle scroll animations
const setupScrollAnimation = () => {
  const animateOnScroll = () => {
    const elements = document.querySelectorAll('.animate-on-scroll');
    
    elements.forEach(element => {
      const elementPosition = element.getBoundingClientRect().top;
      const windowHeight = window.innerHeight;
      
      if (elementPosition < windowHeight - 100) {
        element.classList.add('visible');
      }
    });
  };
  
  // Initial check
  animateOnScroll();
  
  // Check on scroll
  window.addEventListener('scroll', animateOnScroll);
  
  // Clean up on unmount
  return () => window.removeEventListener('scroll', animateOnScroll);
};

// A global hook that components can use to set up scroll animations
window.setupScrollAnimation = setupScrollAnimation;

createRoot(document.getElementById("root")!).render(<App />);
