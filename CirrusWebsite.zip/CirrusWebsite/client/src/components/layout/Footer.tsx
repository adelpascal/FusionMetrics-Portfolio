import { Link } from "wouter";

export default function Footer() {
  // Handle smooth scrolling for anchor links
  const scrollToSection = (sectionId: string) => {
    const targetElement = document.getElementById(sectionId);
    
    if (targetElement) {
      window.scrollTo({
        top: targetElement.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <footer className="bg-neutral text-white py-12">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          <div className="md:col-span-4">
            <div className="font-montserrat font-bold text-2xl text-white mb-4">
              Cirrus<span className="text-secondary">Carbon</span>
            </div>
            <p className="text-white/80 mb-6">
              Removing carbon dioxide from the atmosphere through innovative Direct Air Capture technology.
            </p>
            <div className="text-white/60 text-sm">
              <p>© {new Date().getFullYear()} Cirrus Carbon. All rights reserved.</p>
            </div>
          </div>
          
          <div className="md:col-span-2">
            <h4 className="font-montserrat font-semibold text-lg mb-4">Company</h4>
            <ul className="space-y-2">
              <li>
                <a 
                  href="#mission"
                  onClick={() => scrollToSection('mission')}
                  className="text-white/80 hover:text-white transition-colors"
                >
                  Mission
                </a>
              </li>
              <li>
                <a 
                  href="#about"
                  onClick={() => scrollToSection('about')}
                  className="text-white/80 hover:text-white transition-colors"
                >
                  About Us
                </a>
              </li>
              <li>
                <a 
                  href="#about"
                  onClick={() => scrollToSection('about')}
                  className="text-white/80 hover:text-white transition-colors"
                >
                  Founder
                </a>
              </li>
              <li>
                <a href="#" className="text-white/80 hover:text-white transition-colors">Careers</a>
              </li>
            </ul>
          </div>
          
          <div className="md:col-span-2">
            <h4 className="font-montserrat font-semibold text-lg mb-4">Technology</h4>
            <ul className="space-y-2">
              <li>
                <a 
                  href="#technology"
                  onClick={() => scrollToSection('technology')}
                  className="text-white/80 hover:text-white transition-colors"
                >
                  How It Works
                </a>
              </li>
              <li>
                <a href="#" className="text-white/80 hover:text-white transition-colors">Research</a>
              </li>
              <li>
                <a href="#" className="text-white/80 hover:text-white transition-colors">Patents</a>
              </li>
              <li>
                <a href="#" className="text-white/80 hover:text-white transition-colors">Partnerships</a>
              </li>
            </ul>
          </div>
          
          <div className="md:col-span-2">
            <h4 className="font-montserrat font-semibold text-lg mb-4">Resources</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-white/80 hover:text-white transition-colors">Blog</a>
              </li>
              <li>
                <a href="#" className="text-white/80 hover:text-white transition-colors">News</a>
              </li>
              <li>
                <a href="#" className="text-white/80 hover:text-white transition-colors">Press Kit</a>
              </li>
              <li>
                <a href="#" className="text-white/80 hover:text-white transition-colors">FAQs</a>
              </li>
            </ul>
          </div>
          
          <div className="md:col-span-2">
            <h4 className="font-montserrat font-semibold text-lg mb-4">Legal</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-white/80 hover:text-white transition-colors">Privacy Policy</a>
              </li>
              <li>
                <a href="#" className="text-white/80 hover:text-white transition-colors">Terms of Use</a>
              </li>
              <li>
                <a href="#" className="text-white/80 hover:text-white transition-colors">Cookie Policy</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
}
