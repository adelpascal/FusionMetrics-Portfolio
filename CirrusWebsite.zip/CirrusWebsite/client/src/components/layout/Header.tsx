import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Menu, X } from "lucide-react";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  // Toggle mobile menu
  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  
  // Handle scroll behavior for navbar
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      setIsScrolled(scrollPosition > 50);
    };

    window.addEventListener("scroll", handleScroll);
    
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  // Handle smooth scrolling for anchor links
  const scrollToSection = (sectionId: string) => {
    // Close mobile menu if open
    if (isMenuOpen) {
      setIsMenuOpen(false);
    }
    
    const targetElement = document.getElementById(sectionId);
    
    if (targetElement) {
      window.scrollTo({
        top: targetElement.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <header 
      className={`fixed w-full bg-white bg-opacity-95 shadow-sm z-50 transition-all duration-300 ${
        isScrolled ? "py-2 shadow" : "py-4"
      }`} 
      id="navbar"
    >
      <div className="container mx-auto px-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            {/* Logo */}
            <a href="#hero" onClick={() => scrollToSection('hero')} className="flex items-center">
              <span className="font-montserrat font-bold text-2xl text-primary">
                Cirrus<span className="text-secondary">Carbon</span>
              </span>
            </a>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-10">
            <a 
              href="#mission" 
              onClick={() => scrollToSection('mission')}
              className="text-neutral hover:text-primary transition-colors font-medium"
            >
              Mission
            </a>
            <a 
              href="#technology" 
              onClick={() => scrollToSection('technology')}
              className="text-neutral hover:text-primary transition-colors font-medium"
            >
              Technology
            </a>
            <a 
              href="#about" 
              onClick={() => scrollToSection('about')}
              className="text-neutral hover:text-primary transition-colors font-medium"
            >
              About
            </a>
            <a 
              href="#contact" 
              onClick={() => scrollToSection('contact')}
              className="text-neutral hover:text-primary transition-colors font-medium"
            >
              Contact
            </a>
          </nav>
          
          {/* Mobile Menu Button */}
          <button 
            onClick={toggleMenu}
            className="md:hidden text-neutral focus:outline-none"
          >
            {isMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
          </button>
        </div>
        
        {/* Mobile Navigation */}
        <div className={`md:hidden pt-4 pb-2 ${isMenuOpen ? 'block' : 'hidden'}`}>
          <nav className="flex flex-col space-y-4">
            <a 
              href="#mission" 
              onClick={() => scrollToSection('mission')}
              className="text-neutral hover:text-primary transition-colors font-medium"
            >
              Mission
            </a>
            <a 
              href="#technology" 
              onClick={() => scrollToSection('technology')}
              className="text-neutral hover:text-primary transition-colors font-medium"
            >
              Technology
            </a>
            <a 
              href="#about" 
              onClick={() => scrollToSection('about')}
              className="text-neutral hover:text-primary transition-colors font-medium"
            >
              About
            </a>
            <a 
              href="#contact" 
              onClick={() => scrollToSection('contact')}
              className="text-neutral hover:text-primary transition-colors font-medium"
            >
              Contact
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
}
