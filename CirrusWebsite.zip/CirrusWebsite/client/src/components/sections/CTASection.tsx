import { Button } from "@/components/ui/button";

export default function CTASection() {
  // Handle smooth scrolling for anchor links
  const scrollToSection = (sectionId: string) => {
    const targetElement = document.getElementById(sectionId);
    
    if (targetElement) {
      window.scrollTo({
        top: targetElement.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section className="py-16 md:py-24 bg-primary text-white">
      <div className="container mx-auto px-6 text-center animate-on-scroll">
        <h2 className="font-montserrat font-bold text-3xl md:text-4xl mb-6">Join Our Climate Mission</h2>
        <p className="text-lg max-w-2xl mx-auto mb-8 text-white/90">
          Whether you're an investor, potential partner, or climate enthusiast, we'd love to connect with you and explore how we can work together to scale carbon removal.
        </p>
        <Button 
          onClick={() => scrollToSection('contact')}
          size="lg"
          variant="outline"
          className="bg-white text-primary hover:bg-gray-100 font-semibold rounded-full shadow-lg hover:shadow-xl transform transition-all hover:-translate-y-1 px-10 text-lg"
        >
          Get in Touch
        </Button>
      </div>
    </section>
  );
}
