import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

export default function TechnologySection() {
  // Handle smooth scrolling for anchor links
  const scrollToSection = (sectionId: string) => {
    const targetElement = document.getElementById(sectionId);
    
    if (targetElement) {
      window.scrollTo({
        top: targetElement.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="technology" className="py-16 md:py-24 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-on-scroll">
          <h2 className="font-montserrat font-bold text-3xl md:text-4xl text-neutral mb-6 inline-block relative">
            <span className="inline-block pb-2 section-heading-center">Our Technology</span>
          </h2>
          <p className="text-lg max-w-3xl mx-auto text-neutral/90">
            Cirrus Carbon's proprietary Direct Air Capture technology efficiently removes CO₂ from ambient air and permanently stores it, helping to reverse climate change at scale.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {/* Technology Card 1 */}
          <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden animate-on-scroll">
            <div className="h-48 overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1581094794329-c8112a89af12?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500" 
                alt="Carbon capture technology" 
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
              />
            </div>
            <div className="p-6">
              <h3 className="font-montserrat font-semibold text-xl mb-3 text-primary">Capture Technology</h3>
              <p className="text-neutral/80 mb-4">
                Our specialized sorbent materials efficiently bind CO₂ from ambient air, even at low concentrations, with minimal energy requirements.
              </p>
              <div className="flex items-center justify-between text-sm text-neutral/70">
                <span className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-secondary mr-1" />
                  <span>Energy Efficient</span>
                </span>
                <span className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-secondary mr-1" />
                  <span>Scalable Design</span>
                </span>
              </div>
            </div>
          </div>
          
          {/* Technology Card 2 */}
          <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden animate-on-scroll">
            <div className="h-48 overflow-hidden">
              <img 
                src="https://pixabay.com/get/g5164684b07986b13e2398d7522343c059b1fadc9ac1df06076c741860203bb64a841264bfe229faed1b1cecd0ed8ad2fbd01f67f5cf3dc28d8bf2dfb263fe4c5_1280.jpg" 
                alt="Carbon storage facility" 
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
              />
            </div>
            <div className="p-6">
              <h3 className="font-montserrat font-semibold text-xl mb-3 text-primary">Storage Solutions</h3>
              <p className="text-neutral/80 mb-4">
                We transform captured CO₂ into stable forms for permanent geological sequestration or convert it into valuable carbon-negative materials.
              </p>
              <div className="flex items-center justify-between text-sm text-neutral/70">
                <span className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-secondary mr-1" />
                  <span>Permanent Storage</span>
                </span>
                <span className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-secondary mr-1" />
                  <span>Verified Credits</span>
                </span>
              </div>
            </div>
          </div>
          
          {/* Technology Card 3 */}
          <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden animate-on-scroll">
            <div className="h-48 overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500" 
                alt="Modular carbon capture system" 
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
              />
            </div>
            <div className="p-6">
              <h3 className="font-montserrat font-semibold text-xl mb-3 text-primary">Deployment System</h3>
              <p className="text-neutral/80 mb-4">
                Our modular design allows for rapid deployment and scaling of capture units across diverse locations to maximize global impact.
              </p>
              <div className="flex items-center justify-between text-sm text-neutral/70">
                <span className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-secondary mr-1" />
                  <span>Modular Design</span>
                </span>
                <span className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-secondary mr-1" />
                  <span>Adaptive Placement</span>
                </span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-16 text-center animate-on-scroll">
          <Button 
            onClick={() => scrollToSection('contact')}
            size="lg"
            className="bg-primary hover:bg-primary/90 text-white font-semibold rounded-full shadow-lg hover:shadow-xl transform transition-all hover:-translate-y-1 px-8"
          >
            Learn More About Our Technology
          </Button>
        </div>
      </div>
    </section>
  );
}
