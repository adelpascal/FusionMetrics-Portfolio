import { Leaf, FlaskRound } from "lucide-react";

export default function MissionSection() {
  return (
    <section id="mission" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="animate-on-scroll">
            {/* Earth image */}
            <img 
              src="https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Earth's atmosphere" 
              className="rounded-lg shadow-xl w-full h-auto"
            />
          </div>
          
          <div className="animate-on-scroll">
            <h2 className="section-heading">
              <span className="inline-block pb-2 relative">Our Mission</span>
            </h2>
            <p className="text-lg mb-6 text-neutral/90">
              At Cirrus Carbon, we're dedicated to reversing climate change by removing excess carbon dioxide from the atmosphere through innovative Direct Air Capture (DAC) technology.
            </p>
            <p className="text-lg mb-6 text-neutral/90">
              Our mission is to scale carbon removal technology to gigaton levels, making a meaningful impact on atmospheric CO₂ concentrations while creating a sustainable business model that benefits both the planet and our stakeholders.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-8">
              <div className="bg-light p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="text-primary text-3xl mb-3">
                  <Leaf className="h-8 w-8" />
                </div>
                <h3 className="font-montserrat font-semibold text-xl mb-2">Sustainability</h3>
                <p className="text-neutral/80">Creating carbon-negative operations that restore climate balance.</p>
              </div>
              <div className="bg-light p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                <div className="text-primary text-3xl mb-3">
                  <FlaskRound className="h-8 w-8" />
                </div>
                <h3 className="font-montserrat font-semibold text-xl mb-2">Innovation</h3>
                <p className="text-neutral/80">Developing breakthrough technologies for industrial-scale carbon capture.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
