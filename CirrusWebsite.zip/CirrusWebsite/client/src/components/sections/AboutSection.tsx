export default function AboutSection() {
  return (
    <section id="about" className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 animate-on-scroll">
          <h2 className="font-montserrat font-bold text-3xl md:text-4xl text-neutral mb-6 inline-block relative">
            <span className="inline-block pb-2 section-heading-center">About Us</span>
          </h2>
          <p className="text-lg max-w-3xl mx-auto text-neutral/90">
            Founded by Adelia Nur Fasha, Cirrus Carbon is driven by a passionate vision to tackle one of humanity's greatest challenges through innovative carbon capture technology.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <div className="animate-on-scroll">
            <h3 className="font-montserrat font-semibold text-2xl mb-6 text-primary">Our Story</h3>
            <p className="text-neutral/80 mb-4">
              Cirrus Carbon was born from a simple but powerful idea: we need to do more than just reduce emissions – we need to actively remove carbon dioxide from the atmosphere to restore climate balance.
            </p>
            <p className="text-neutral/80 mb-4">
              The innovative design of our proprietary Direct Air Capture system focuses on efficiency, scalability, and cost-effectiveness - all essential elements for making a meaningful impact on atmospheric carbon levels.
            </p>
            <p className="text-neutral/80 mb-4">
              Today, we're a pre-seed startup focused on building our first commercial-scale demonstration facility while forming partnerships across industries to create a robust carbon removal ecosystem.
            </p>
            
            <div className="grid grid-cols-2 gap-6 mt-8">
              <div className="bg-light p-4 rounded-lg">
                <div className="text-primary font-montserrat font-bold text-3xl">95%</div>
                <div className="text-neutral/80 text-sm">Capture Efficiency</div>
              </div>
              <div className="bg-light p-4 rounded-lg">
                <div className="text-primary font-montserrat font-bold text-3xl">60%</div>
                <div className="text-neutral/80 text-sm">Lower Energy Usage</div>
              </div>
              <div className="bg-light p-4 rounded-lg">
                <div className="text-primary font-montserrat font-bold text-2xl">1000+</div>
                <div className="text-neutral/80 text-sm">Tons CO₂ Captured</div>
              </div>
              <div className="bg-light p-4 rounded-lg">
                <div className="text-primary font-montserrat font-bold text-3xl">{new Date().getFullYear()}</div>
                <div className="text-neutral/80 text-sm">Founded</div>
              </div>
            </div>
          </div>
          
          <div className="animate-on-scroll">
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1531482615713-2afd69097998?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Cirrus Carbon founder" 
                className="rounded-lg shadow-xl w-full"
              />
              <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-lg shadow-lg">
                <div>
                  <div className="font-montserrat font-semibold text-sm">Adelia Nur Fasha</div>
                  <div className="text-xs text-neutral/70">Founder & CEO</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
