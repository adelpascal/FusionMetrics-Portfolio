import { ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function HeroSection() {
  // Handle smooth scrolling for anchor links
  const scrollToSection = (sectionId: string) => {
    const targetElement = document.getElementById(sectionId);
    
    if (targetElement) {
      window.scrollTo({
        top: targetElement.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section 
      id="hero" 
      className="relative h-screen flex items-center justify-center" 
      style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1511497584788-876760111969?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080")',
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <div className="absolute inset-0 bg-neutral opacity-60"></div>
      <div className="container mx-auto px-6 z-10 text-center">
        <h1 className="font-montserrat font-bold text-4xl md:text-5xl lg:text-6xl text-white mb-6 drop-shadow-lg animate-on-scroll visible">
          Capturing Carbon,<br/>Restoring Our Climate
        </h1>
        <p className="text-white text-xl md:text-2xl max-w-3xl mx-auto mb-10 drop-shadow-md animate-on-scroll visible">
          Cirrus Carbon's breakthrough Direct Air Capture technology removes CO₂ directly from the atmosphere for a sustainable future.
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4 animate-on-scroll visible">
          <Button 
            onClick={() => scrollToSection('technology')}
            size="lg"
            className="bg-primary hover:bg-primary/90 text-white font-semibold rounded-full shadow-lg hover:shadow-xl transform transition-all hover:-translate-y-1 px-8"
          >
            Our Technology
          </Button>
          <Button 
            onClick={() => scrollToSection('contact')} 
            variant="outline"
            size="lg"
            className="bg-white hover:bg-gray-100 text-primary font-semibold rounded-full shadow-lg hover:shadow-xl transform transition-all hover:-translate-y-1 px-8"
          >
            Get in Touch
          </Button>
        </div>
      </div>
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 animate-bounce">
        <a 
          href="#mission" 
          onClick={(e) => {
            e.preventDefault();
            scrollToSection('mission');
          }}
          className="text-white opacity-80 hover:opacity-100 transition-opacity"
        >
          <ChevronDown className="h-6 w-6" />
        </a>
      </div>
    </section>
  );
}
