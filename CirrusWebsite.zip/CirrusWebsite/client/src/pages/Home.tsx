import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import HeroSection from "@/components/sections/HeroSection";
import MissionSection from "@/components/sections/MissionSection";
import TechnologySection from "@/components/sections/TechnologySection";
import AboutSection from "@/components/sections/AboutSection";
import CTASection from "@/components/sections/CTASection";
import ContactSection from "@/components/sections/ContactSection";
import { useEffect } from "react";

export default function Home() {
  // This component will load the sections in order
  return (
    <>
      <Header />
      <main>
        <HeroSection />
        <MissionSection />
        <TechnologySection />
        <AboutSection />
        <CTASection />
        <ContactSection />
      </main>
      <Footer />
    </>
  );
}
