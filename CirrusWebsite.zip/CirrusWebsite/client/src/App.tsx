import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import { useEffect } from "react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  // Setup scroll animation effect when the application loads
  useEffect(() => {
    // This uses the function exported in main.tsx
    if (window.setupScrollAnimation) {
      const cleanupFn = window.setupScrollAnimation();
      return cleanupFn;
    }
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

// Add global type for the scroll animation function
declare global {
  interface Window {
    setupScrollAnimation?: () => () => void;
  }
}

export default App;
